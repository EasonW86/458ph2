Installing PT and S/SL syntax colouring in Vim 8.x
---------------------------------------------------

To install PT Pascal and S/SL source file colouring in Vim 8.x,
from this current directory use the command:

        cp -R dotvim ~/.vim
