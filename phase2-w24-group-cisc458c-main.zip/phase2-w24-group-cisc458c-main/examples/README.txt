Some example PT programs.
